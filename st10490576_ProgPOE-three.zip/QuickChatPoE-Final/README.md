# PoePart1 - QuickChat (Part 3)

Register -> Login -> QuickChat. Built with Maven, Gson (JSON) and JUnit 5.

## Run
- NetBeans: open the folder as a Maven project, run `poepart1.PoePart1`.
- Tests: `mvn clean test`

## Main menu
1) Send Messages  2) Show recently sent messages  3) Quit  4) Stored Messages

## Stored Messages menu
Works on "kept" messages (sent + stored; disregarded are excluded):
1 sender/recipient list, 2 longest message, 3 search by message ID, 4 search by recipient,
5 delete by message hash, 6 full report.

## Arrays (MessageManager)
sentMessages, disregardedMessages, storedMessages (loaded from `stored_messages.json`),
messageHashes, messageIds - all filled from user input, nothing hard-coded.

## Classes
Registration, Login, Message (model + rules), MessageManager (arrays + features),
MessageStorage (Gson read/write), QuickChat (screens), PoePart1 (main).
