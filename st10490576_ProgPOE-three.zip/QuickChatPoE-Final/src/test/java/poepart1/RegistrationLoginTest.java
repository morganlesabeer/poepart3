package poepart1;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class RegistrationLoginTest {

    private final Login login = new Login();

    @Test
    void usernameNeedsUnderscoreAndMaxFiveCharacters() {
        assertTrue(login.checkUserName("kyl_1"));
        assertFalse(login.checkUserName("kyle!!!!!!"));
        assertFalse(login.checkUserName("kyle1"));
        assertFalse(login.checkUserName(null));
    }

    @Test
    void passwordComplexity() {
        assertTrue(login.checkPasswordComplexity("Ch&&sec@ke99!"));
        assertFalse(login.checkPasswordComplexity("password"));
        assertFalse(login.checkPasswordComplexity("User"));
    }

    @Test
    void cellphoneNumber() {
        assertTrue(login.checkCellPhoneNumber("+27838968976"));
        assertTrue(login.checkCellPhoneNumber("0838968976"));
        assertFalse(login.checkCellPhoneNumber("08966553"));
        assertFalse(login.checkCellPhoneNumber("+2783896897612"));
        assertFalse(login.checkCellPhoneNumber(""));
    }

    @Test
    void registerAndLogin() {
        assertEquals("Registration was a success",
                login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976"));
        assertTrue(login.loginUser("kyl_1", "Ch&&sec@ke99!"));
        assertEquals("Login success", login.returnLoginStatus(true));
        assertFalse(login.loginUser("kyl_1", "wrong"));
        assertEquals("Login failed", login.returnLoginStatus(false));
    }

    @Test
    void failedRegistrationCannotLogin() {
        assertEquals("Registration was unsuccessful", login.registerUser("kyle!!!!!!", "x", "123"));
        assertFalse(login.loginUser("kyle!!!!!!", "x"));
    }
}
