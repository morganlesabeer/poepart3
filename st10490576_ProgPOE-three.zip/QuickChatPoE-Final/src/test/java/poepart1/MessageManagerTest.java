package poepart1;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;




class MessageManagerTest {

    @TempDir
    Path tempDir;

    private MessageManager manager;

    private static final String MSG1 = "Did you get the cake?";
    private static final String MSG2 = "Where are you? You are late! I have asked you to be on time.";
    private static final String MSG3 = "Yohoooo, I am at your gate.";
    private static final String MSG4 = "It is dinner time!";
    private static final String MSG5 = "Ok, I am leaving without you.";

    private static Message test1() { return new Message("1234567890", 1, "Developer", "+27834557896", MSG1, Message.SENT); }
    private static Message test2() { return new Message("2345678901", 2, "Developer", "+27838884567", MSG2, Message.STORED); }
    private static Message test3() { return new Message("3456789012", 3, "Developer", "+27834484567", MSG3, Message.DISREGARD); }
    private static Message test4() { return new Message("4567890123", 4, "Developer", "0838884567", MSG4, Message.SENT); }
    private static Message test5() { return new Message("5678901234", 5, "Developer", "+27838884567", MSG5, Message.STORED); }

    @BeforeEach
    void setUp() {
        manager = new MessageManager(null);
    }

    private void loadMessages1to4() {
        manager.addMessage(test1());
        manager.addMessage(test2());
        manager.addMessage(test3());
        manager.addMessage(test4());
    }

    private void loadAllMessages() {
        loadMessages1to4();
        manager.addMessage(test5());
    }

    

    @Test
    void sentMessagesArrayCorrectlyPopulated() {
        loadMessages1to4();
        List<String> sent = manager.getSentMessages().stream().map(Message::getText).toList();
        assertEquals(List.of("Did you get the cake?", "It is dinner time!"), sent);
    }

    @Test
    void displayLongestMessage() {
        loadMessages1to4();
        assertEquals("Where are you? You are late! I have asked you to be on time.",
                manager.displayLongestMessage());
    }

    @Test
    void searchForMessageId() {
        loadMessages1to4();
        Message found = manager.findById("4567890123");
        assertNotNull(found);
        assertEquals("It is dinner time!", found.getText());
        assertEquals("0838884567", found.getRecipient());
        assertEquals("Recipient: 0838884567\nMessage: It is dinner time!",
                manager.searchByMessageId("4567890123"));
    }

    @Test
    void searchAllMessagesForARecipient() {
        loadAllMessages();
        List<String> texts = manager.searchByRecipient("+27838884567").stream().map(Message::getText).toList();
        assertEquals(List.of("Where are you? You are late! I have asked you to be on time.",
                "Ok, I am leaving without you."), texts);
    }

    @Test
    void deleteMessageUsingHash() {
        loadAllMessages();
        String hash = test2().getMessageHash();
        assertEquals("Message: \"Where are you? You are late! I have asked you to be on time.\" successfully deleted.",
                manager.deleteByHash(hash));
        assertNull(manager.findById("2345678901"));
        assertFalse(manager.getMessageHashes().contains(hash));
        assertFalse(manager.getMessageIds().contains("2345678901"));
    }

    @Test
    void displayReport() {
        loadAllMessages();
        String report = manager.displayReport();

        assertEquals(List.of("12:1:DIDCAKE?", "23:2:WHERETIME.", "45:4:ITTIME!", "56:5:OK,YOU."),
                reportValues(report, "Message Hash: "));
        assertEquals(List.of("+27834557896", "+27838884567", "0838884567", "+27838884567"),
                reportValues(report, "Recipient:    "));
        assertEquals(List.of(MSG1, MSG2, MSG4, MSG5),
                reportValues(report, "Message:      "));
        assertEquals(List.of("2 | Stored: 2 | Disregarded: 1"),
                reportValues(report, "Sent: "));
        assertFalse(report.contains(MSG3));
    }

    
    private static List<String> reportValues(String report, String label) {
        return report.lines()
                .filter(line -> line.startsWith(label))
                .map(line -> line.substring(label.length()).trim())
                .toList();
    }

    

    @Test
    void messagesLandInTheCorrectArrays() {
        loadAllMessages();
        assertEquals(2, manager.getSentMessages().size());
        assertEquals(2, manager.getStoredMessages().size());
        assertEquals(1, manager.getDisregardedMessages().size());
        assertEquals(MSG3, manager.getDisregardedMessages().get(0).getText());
        assertEquals(5, manager.getMessageHashes().size());
        assertEquals(5, manager.getMessageIds().size());
        assertEquals(2, manager.returnTotalMessages());
    }

    @Test
    void messageHashFormat() {
        assertEquals("12:1:DIDCAKE?", test1().getMessageHash());
        assertEquals("45:4:ITTIME!", test4().getMessageHash());
        assertEquals("00:1:HELLOHELLO", Message.createMessageHash("0012345678", 1, "Hello"));
    }

    @Test
    void recipientAndIdValidation() {
        assertEquals("Valid number", Message.checkRecipientCell("+27838884567"));
        assertEquals("Valid number", Message.checkRecipientCell("0838884567"));
        assertEquals("Invalid number", Message.checkRecipientCell("08575975889"));
        assertEquals("Invalid number", Message.checkRecipientCell(""));
        assertTrue(Message.checkMessageID("1234567890"));
        assertFalse(Message.checkMessageID("12345678901"));
    }

    @Test
    void sendersAndRecipientsListing() {
        loadAllMessages();
        String listing = manager.displaySendersAndRecipients();
        assertTrue(listing.contains("Sender: Developer | Recipient: +27834557896"));
        assertFalse(listing.contains("+27834484567"), "disregarded recipient must not be listed");
    }

    @Test
    void createMessageGivesUniqueIdsAndNumbers() {
        Message a = manager.createMessage("Developer", "0838884567", "Hello there", Message.SENT);
        manager.addMessage(a);
        Message b = manager.createMessage("Developer", "0838884567", "Hello again", Message.SENT);
        assertEquals(1, a.getMessageNumber());
        assertEquals(2, b.getMessageNumber());
        assertTrue(Message.checkMessageID(a.getMessageId()));
        assertFalse(a.getMessageId().equals(b.getMessageId()));
    }

    @Test
    void storedMessagesAreSavedToJsonAndReadBack() throws IOException {
        Path file = tempDir.resolve("stored_messages.json");

        MessageManager first = new MessageManager(file);
        first.addMessage(test2());
        first.addMessage(test5());

        MessageManager second = new MessageManager(file);
        assertEquals(2, second.loadStoredMessages());
        assertEquals(List.of(MSG2, MSG5),
                second.getStoredMessages().stream().map(Message::getText).toList());
        assertEquals(test2().getMessageHash(), second.getStoredMessages().get(0).getMessageHash());
        assertEquals(2, second.getMessageHashes().size());
    }

    @Test
    void deletingAStoredMessageUpdatesTheJsonFile() {
        Path file = tempDir.resolve("stored_messages.json");

        MessageManager first = new MessageManager(file);
        first.addMessage(test2());
        first.addMessage(test5());
        first.deleteByHash(test2().getMessageHash());

        MessageManager second = new MessageManager(file);
        assertEquals(1, second.loadStoredMessages());
        assertEquals(MSG5, second.getStoredMessages().get(0).getText());
    }

    @Test
    void deleteWithUnknownHash() {
        loadAllMessages();
        assertEquals("No message found with hash: NOPE", manager.deleteByHash("NOPE"));
    }
}
