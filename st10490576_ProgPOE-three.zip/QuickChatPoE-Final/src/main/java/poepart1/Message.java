package poepart1;

import java.util.Random;
import java.util.Set;




public class Message {

    public static final String SENT = "Sent";
    public static final String STORED = "Stored";
    public static final String DISREGARD = "Disregard";

    public static final int MAX_MESSAGE_LENGTH = 250;

    private String messageId;
    private int messageNumber;
    private String messageHash;
    private String sender;
    private String recipient;
    private String text;
    private String flag;

    public Message(String messageId, int messageNumber, String sender,
                   String recipient, String text, String flag) {
        this.messageId = messageId;
        this.messageNumber = messageNumber;
        this.sender = sender;
        this.recipient = recipient;
        this.text = text;
        this.flag = flag;
        this.messageHash = createMessageHash(messageId, messageNumber, text);
    }

    

    
    public static boolean checkMessageID(String messageId) {
        return messageId != null && !messageId.isEmpty() && messageId.length() <= 10;
    }

    
    public static String checkRecipientCell(String cellphone) {
        if (cellphone != null
                && (cellphone.matches("^\\+27[0-9]{9}$") || cellphone.matches("^0[0-9]{9}$"))) {
            return "Valid number";
        }
        return "Invalid number";
    }

    
    public static String createMessageHash(String messageId, int messageNumber, String messageText) {
        String firstTwo = messageId.substring(0, Math.min(2, messageId.length()));
        String[] words = messageText.trim().split("\\s+");
        String firstWord = words[0];
        String lastWord = words[words.length - 1];
        return (firstTwo + ":" + messageNumber + ":" + firstWord + lastWord).toUpperCase();
    }

    
    public static String generateMessageID(Random random, Set<String> idsInUse) {
        String id;
        do {
            id = String.valueOf(1_000_000_000L + random.nextLong(9_000_000_000L));
        } while (idsInUse.contains(id));
        return id;
    }

    

    public String getMessageId() { return messageId; }
    public int getMessageNumber() { return messageNumber; }
    public String getMessageHash() { return messageHash; }
    public String getSender() { return sender; }
    public String getRecipient() { return recipient; }
    public String getText() { return text; }
    public String getFlag() { return flag; }
}
