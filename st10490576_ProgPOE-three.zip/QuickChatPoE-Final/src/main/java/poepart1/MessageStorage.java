package poepart1;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;







public class MessageStorage {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Type LIST_TYPE = new TypeToken<ArrayList<Message>>() { }.getType();

    private MessageStorage() { }

    public static void save(Path file, List<Message> messages) throws IOException {
        try (Writer writer = Files.newBufferedWriter(file, StandardCharsets.UTF_8)) {
            GSON.toJson(messages, LIST_TYPE, writer);
        }
    }

    
    public static List<Message> load(Path file) throws IOException {
        if (file == null || !Files.exists(file)) {
            return new ArrayList<>();
        }
        try (Reader reader = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            List<Message> loaded = GSON.fromJson(reader, LIST_TYPE);
            return loaded == null ? new ArrayList<>() : loaded;
        }
    }
}
