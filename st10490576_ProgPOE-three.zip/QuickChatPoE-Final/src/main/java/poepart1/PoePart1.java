package poepart1;

import javax.swing.JOptionPane;




public class PoePart1 {

    public static void main(String[] args) {
        Login login = new Login();

        JOptionPane.showMessageDialog(null, "===== Register =====", "Registration",
                JOptionPane.INFORMATION_MESSAGE);

        
        while (true) {
            String username = JOptionPane.showInputDialog(null,
                    "Username (must contain an underscore and be no more than 5 characters):");
            if (username == null) {
                return;
            }
            String password = JOptionPane.showInputDialog(null,
                    "Password (8+ characters, with a capital letter, number and special character):");
            if (password == null) {
                return;
            }
            String cellphone = JOptionPane.showInputDialog(null,
                    "Cellphone number (e.g. +27831234567):");
            if (cellphone == null) {
                return;
            }

            String result = login.registerUser(username, password, cellphone);
            JOptionPane.showMessageDialog(null, result);
            if (login.registerStatus(username, password, cellphone)) {
                break;
            }
        }

        JOptionPane.showMessageDialog(null, "===== Login =====", "Login",
                JOptionPane.INFORMATION_MESSAGE);

        while (true) {
            String loginUsername = JOptionPane.showInputDialog(null, "Enter username to login:");
            if (loginUsername == null) {
                return;
            }
            String loginPassword = JOptionPane.showInputDialog(null, "Enter password to login:");
            if (loginPassword == null) {
                return;
            }

            boolean status = login.loginUser(loginUsername, loginPassword);
            JOptionPane.showMessageDialog(null, login.returnLoginStatus(status));
            if (status) {
                break;
            }
        }

        new QuickChat(login.getUserName()).run();
    }
}
