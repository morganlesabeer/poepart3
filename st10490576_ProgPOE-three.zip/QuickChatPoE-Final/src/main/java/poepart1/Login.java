package poepart1;

import java.util.Objects;




public class Login extends Registration {

    public boolean loginUser(String name, String password) {
        return userName != null
                && Objects.equals(name, userName)
                && Objects.equals(password, passWord);
    }

    public String returnLoginStatus(boolean loginStatus) {
        return loginStatus ? "Login success" : "Login failed";
    }
}
