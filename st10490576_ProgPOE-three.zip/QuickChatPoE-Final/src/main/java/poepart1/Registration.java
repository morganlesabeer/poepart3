package poepart1;




public class Registration {

    String userName;
    String passWord;
    String cellPhone;

    
    public boolean checkUserName(String username) {
        return username != null
                && username.contains("_")
                && username.length() <= 5;
    }

    
    public boolean checkPasswordComplexity(String password) {
        return password != null
                && password.length() >= 8
                && password.matches(".*[A-Z].*")
                && password.matches(".*[a-z].*")
                && password.matches(".*\\d.*")
                && password.matches(".*[^a-zA-Z0-9].*");
    }

    
    public boolean checkCellPhoneNumber(String cellphone) {
        return cellphone != null
                && (cellphone.matches("^\\+27[0-9]{9}$") || cellphone.matches("^0[0-9]{9}$"));
    }

    public String registerUser(String username, String password, String cellphone) {
        if (registerStatus(username, password, cellphone)) {
            this.userName = username;
            this.passWord = password;
            this.cellPhone = cellphone;
            return "Registration was a success";
        }
        return "Registration was unsuccessful";
    }

    public boolean registerStatus(String username, String password, String cellphone) {
        return checkUserName(username)
                && checkPasswordComplexity(password)
                && checkCellPhoneNumber(cellphone);
    }

    public String getUserName() {
        return userName;
    }
}
