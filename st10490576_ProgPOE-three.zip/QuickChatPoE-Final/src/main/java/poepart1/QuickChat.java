package poepart1;

import java.awt.Font;
import java.io.UncheckedIOException;
import java.nio.file.Path;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;




public class QuickChat {

    private final MessageManager manager;
    private final String loggedInUser;

    public QuickChat(String loggedInUser) {
        this.loggedInUser = loggedInUser;
        this.manager = new MessageManager(Path.of("stored_messages.json"));
        try {
            int loaded = manager.loadStoredMessages();
            if (loaded > 0) {
                JOptionPane.showMessageDialog(null, loaded + " stored message(s) loaded from file.");
            }
        } catch (UncheckedIOException e) {
            showError("Could not read the stored messages file: " + e.getCause().getMessage());
        }
    }

    public void run() {
        JOptionPane.showMessageDialog(null, "Welcome to QuickChat.");

        while (true) {
            String choice = JOptionPane.showInputDialog(null,
                    "1) Send Messages\n2) Show recently sent messages\n3) Quit\n4) Stored Messages"
                    + "\n\nChoose an option:",
                    "QuickChat", JOptionPane.QUESTION_MESSAGE);

            if (choice == null) {
                return;
            }
            switch (choice.trim()) {
                case "1" -> sendMessages();
                case "2" -> showText(manager.printMessages(), "Recently sent messages");
                case "3" -> {
                    JOptionPane.showMessageDialog(null, "Goodbye!");
                    return;
                }
                case "4" -> storedMessagesMenu();
                default -> showError("Invalid choice.");
            }
        }
    }

    

    private void sendMessages() {
        Integer howMany = askForPositiveNumber("How many messages do you want to send?");
        if (howMany == null) {
            return;
        }

        for (int i = 1; i <= howMany; i++) {
            String recipient = askRecipient(i, howMany);
            if (recipient == null) {
                return;
            }
            String text = askMessageText();
            if (text == null) {
                return;
            }
            String flag = askWhatToDo();
            if (flag == null) {
                return;
            }

            Message message = manager.createMessage(loggedInUser, recipient, text.trim(), flag);
            try {
                manager.addMessage(message);
            } catch (UncheckedIOException e) {
                showError("Message handled, but the file could not be saved: " + e.getCause().getMessage());
            }

            JOptionPane.showMessageDialog(null,
                    "Message " + flag.toLowerCase() + ".\n\nMessage ID: " + message.getMessageId()
                    + "\nMessage Hash: " + message.getMessageHash()
                    + "\nRecipient: " + message.getRecipient()
                    + "\nMessage: " + message.getText());
        }

        JOptionPane.showMessageDialog(null,
                "Total messages sent: " + manager.returnTotalMessages());
    }

    private Integer askForPositiveNumber(String prompt) {
        while (true) {
            String input = JOptionPane.showInputDialog(null, prompt, "QuickChat", JOptionPane.QUESTION_MESSAGE);
            if (input == null) {
                return null;
            }
            try {
                int n = Integer.parseInt(input.trim());
                if (n >= 1) {
                    return n;
                }
            } catch (NumberFormatException ignored) {
                
            }
            showError("Please enter a whole number greater than 0.");
        }
    }

    private String askRecipient(int number, int total) {
        while (true) {
            String input = JOptionPane.showInputDialog(null,
                    "Message " + number + " of " + total + "\n\nEnter recipient cell number:",
                    "Recipient", JOptionPane.QUESTION_MESSAGE);
            if (input == null) {
                return null;
            }
            if (Message.checkRecipientCell(input.trim()).equals("Valid number")) {
                return input.trim();
            }
            showError("Cell phone number is incorrectly formatted or does not contain an international code. "
                    + "Please correct the number and try again.");
        }
    }

    private String askMessageText() {
        while (true) {
            String input = JOptionPane.showInputDialog(null,
                    "Enter your message (max " + Message.MAX_MESSAGE_LENGTH + " characters):",
                    "Message", JOptionPane.QUESTION_MESSAGE);
            if (input == null) {
                return null;
            }
            if (input.trim().isEmpty()) {
                showError("Please enter a message.");
            } else if (input.length() > Message.MAX_MESSAGE_LENGTH) {
                showError("Message exceeds " + Message.MAX_MESSAGE_LENGTH + " characters by "
                        + (input.length() - Message.MAX_MESSAGE_LENGTH) + ", please reduce size.");
            } else {
                return input;
            }
        }
    }

    private String askWhatToDo() {
        Object[] options = {"Send Message", "Disregard Message", "Store Message to send later"};
        int choice = JOptionPane.showOptionDialog(null,
                "What do you want to do with this message?", "Message options",
                JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
        return switch (choice) {
            case 0 -> Message.SENT;
            case 1 -> Message.DISREGARD;
            case 2 -> Message.STORED;
            default -> null;
        };
    }

    

    private void storedMessagesMenu() {
        while (true) {
            String choice = JOptionPane.showInputDialog(null,
                    "1) Display sender and recipient of all messages"
                    + "\n2) Display the longest message"
                    + "\n3) Search for a message ID"
                    + "\n4) Search messages by recipient"
                    + "\n5) Delete a message using its hash"
                    + "\n6) Display report"
                    + "\n7) Back to main menu"
                    + "\n\nChoose an option:",
                    "Stored Messages", JOptionPane.QUESTION_MESSAGE);

            if (choice == null) {
                return;
            }
            switch (choice.trim()) {
                case "1" -> showText(manager.displaySendersAndRecipients(), "Senders and recipients");
                case "2" -> showText(manager.displayLongestMessage(), "Longest message");
                case "3" -> {
                    String id = ask("Enter the message ID:");
                    if (id != null) {
                        showText(manager.searchByMessageId(id.trim()), "Search result");
                    }
                }
                case "4" -> {
                    String recipient = ask("Enter the recipient's cell number:");
                    if (recipient != null) {
                        showText(manager.displayMessagesForRecipient(recipient.trim()), "Search result");
                    }
                }
                case "5" -> {
                    String hash = ask("Enter the message hash to delete:");
                    if (hash != null) {
                        try {
                            showText(manager.deleteByHash(hash.trim()), "Delete");
                        } catch (UncheckedIOException e) {
                            showError("Deleted, but the file could not be saved: " + e.getCause().getMessage());
                        }
                    }
                }
                case "6" -> showText(manager.displayReport(), "Report");
                case "7" -> {
                    return;
                }
                default -> showError("Invalid choice.");
            }
        }
    }

    

    private String ask(String prompt) {
        return JOptionPane.showInputDialog(null, prompt, "QuickChat", JOptionPane.QUESTION_MESSAGE);
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(null, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    private void showText(String text, String title) {
        JTextArea area = new JTextArea(text, 18, 45);
        area.setEditable(false);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        JOptionPane.showMessageDialog(null, new JScrollPane(area), title, JOptionPane.INFORMATION_MESSAGE);
    }
}
