package poepart1;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Random;







public class MessageManager {

    private final List<Message> sentMessages = new ArrayList<>();
    private final List<Message> disregardedMessages = new ArrayList<>();
    private final List<Message> storedMessages = new ArrayList<>();
    private final List<String> messageHashes = new ArrayList<>();
    private final List<String> messageIds = new ArrayList<>();

    private final Path storageFile; 
    private final Random random = new Random();
    private int messageCounter = 0;

    public MessageManager(Path storageFile) {
        this.storageFile = storageFile;
    }

    

    
    public Message createMessage(String sender, String recipient, String text, String flag) {
        String id = Message.generateMessageID(random, new HashSet<>(messageIds));
        return new Message(id, messageCounter + 1, sender, recipient, text, flag);
    }

    
    public void addMessage(Message message) {
        switch (message.getFlag()) {
            case Message.SENT -> sentMessages.add(message);
            case Message.STORED -> storedMessages.add(message);
            case Message.DISREGARD -> disregardedMessages.add(message);
            default -> throw new IllegalArgumentException("Unknown flag: " + message.getFlag());
        }
        messageHashes.add(message.getMessageHash());
        messageIds.add(message.getMessageId());
        messageCounter = Math.max(messageCounter, message.getMessageNumber());

        if (Message.STORED.equals(message.getFlag())) {
            saveStoredMessages();
        }
    }

    
    public int loadStoredMessages() {
        if (storageFile == null) {
            return 0;
        }
        try {
            int loaded = 0;
            for (Message m : MessageStorage.load(storageFile)) {
                if (!messageIds.contains(m.getMessageId())) {
                    storedMessages.add(m);
                    messageHashes.add(m.getMessageHash());
                    messageIds.add(m.getMessageId());
                    messageCounter = Math.max(messageCounter, m.getMessageNumber());
                    loaded++;
                }
            }
            return loaded;
        } catch (IOException e) {
            throw new UncheckedIOException("Could not read " + storageFile, e);
        }
    }

    private void saveStoredMessages() {
        if (storageFile == null) {
            return;
        }
        try {
            MessageStorage.save(storageFile, storedMessages);
        } catch (IOException e) {
            throw new UncheckedIOException("Could not write " + storageFile, e);
        }
    }

    

    
    public String displaySendersAndRecipients() {
        List<Message> kept = keptMessages();
        if (kept.isEmpty()) {
            return "No messages to display.";
        }
        StringBuilder sb = new StringBuilder();
        for (Message m : kept) {
            sb.append("Sender: ").append(m.getSender())
              .append(" | Recipient: ").append(m.getRecipient()).append("\n");
        }
        return sb.toString().trim();
    }

    
    public Message findLongestMessage() {
        Message longest = null;
        for (Message m : keptMessages()) {
            if (longest == null || m.getText().length() > longest.getText().length()) {
                longest = m;
            }
        }
        return longest;
    }

    public String displayLongestMessage() {
        Message longest = findLongestMessage();
        return longest == null ? "No messages to display." : longest.getText();
    }

    
    public Message findById(String messageId) {
        for (Message m : keptMessages()) {
            if (m.getMessageId().equals(messageId)) {
                return m;
            }
        }
        return null;
    }

    public String searchByMessageId(String messageId) {
        Message m = findById(messageId);
        if (m == null) {
            return "No message found with ID: " + messageId;
        }
        return "Recipient: " + m.getRecipient() + "\nMessage: " + m.getText();
    }

    
    public List<Message> searchByRecipient(String recipient) {
        List<Message> found = new ArrayList<>();
        for (Message m : keptMessages()) {
            if (m.getRecipient().equals(recipient)) {
                found.add(m);
            }
        }
        return found;
    }

    public String displayMessagesForRecipient(String recipient) {
        List<Message> found = searchByRecipient(recipient);
        if (found.isEmpty()) {
            return "No messages found for " + recipient;
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < found.size(); i++) {
            sb.append(i + 1).append(". ").append(found.get(i).getText()).append("\n");
        }
        return sb.toString().trim();
    }

    
    public String deleteByHash(String hash) {
        List<List<Message>> arrays = List.of(sentMessages, storedMessages, disregardedMessages);
        for (List<Message> array : arrays) {
            for (int i = 0; i < array.size(); i++) {
                Message m = array.get(i);
                if (m.getMessageHash().equals(hash)) {
                    array.remove(i);
                    messageHashes.remove(m.getMessageHash());
                    messageIds.remove(m.getMessageId());
                    if (Message.STORED.equals(m.getFlag())) {
                        saveStoredMessages();
                    }
                    return "Message: \"" + m.getText() + "\" successfully deleted.";
                }
            }
        }
        return "No message found with hash: " + hash;
    }

    
    public String displayReport() {
        List<Message> kept = keptMessages();
        if (kept.isEmpty()) {
            return "No messages to report.";
        }
        StringBuilder sb = new StringBuilder("========== MESSAGE REPORT ==========\n");
        for (Message m : kept) {
            sb.append("\nMessage Hash: ").append(m.getMessageHash())
              .append("\nMessage ID:   ").append(m.getMessageId())
              .append("\nSender:       ").append(m.getSender())
              .append("\nRecipient:    ").append(m.getRecipient())
              .append("\nMessage:      ").append(m.getText())
              .append("\nStatus:       ").append(m.getFlag())
              .append("\n------------------------------------\n");
        }
        sb.append("\nSent: ").append(sentMessages.size())
          .append(" | Stored: ").append(storedMessages.size())
          .append(" | Disregarded: ").append(disregardedMessages.size());
        return sb.toString();
    }

    
    public String printMessages() {
        if (sentMessages.isEmpty()) {
            return "No messages have been sent yet.";
        }
        StringBuilder sb = new StringBuilder();
        for (Message m : sentMessages) {
            sb.append("Message ").append(m.getMessageNumber())
              .append(" | ID: ").append(m.getMessageId())
              .append(" | Hash: ").append(m.getMessageHash())
              .append("\n  To: ").append(m.getRecipient())
              .append("\n  ").append(m.getText()).append("\n\n");
        }
        return sb.toString().trim();
    }

    public int returnTotalMessages() {
        return sentMessages.size();
    }

    

    public List<Message> getSentMessages() { return Collections.unmodifiableList(sentMessages); }
    public List<Message> getDisregardedMessages() { return Collections.unmodifiableList(disregardedMessages); }
    public List<Message> getStoredMessages() { return Collections.unmodifiableList(storedMessages); }
    public List<String> getMessageHashes() { return Collections.unmodifiableList(messageHashes); }
    public List<String> getMessageIds() { return Collections.unmodifiableList(messageIds); }

    
    private List<Message> keptMessages() {
        List<Message> kept = new ArrayList<>(sentMessages);
        kept.addAll(storedMessages);
        kept.sort(Comparator.comparingInt(Message::getMessageNumber));
        return kept;
    }
}
